from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import pandas as pd
import os
import subprocess
from datetime import datetime

app = FastAPI(title="Razorpay Reconciliation API")

class OverrideRequest(BaseModel):
    settlement_id: str
    bank_reference: str
    reason: str
    user: str

@app.get("/api/summary")
def get_summary():
    try:
        matched = pd.read_csv("output/settlement_bank_matched.csv")
        review = pd.read_csv("output/settlement_bank_review.csv")
        unmatched = pd.read_csv("output/settlement_bank_unmatched.csv")
        unmatched_bank = pd.read_csv("output/settlement_bank_unmatched_bank.csv")
        return {
            "total_settlements": len(matched) + len(review) + len(unmatched),
            "matched": len(matched),
            "review": len(review),
            "unmatched_settlements": len(unmatched),
            "unmatched_bank_rows": len(unmatched_bank)
        }
    except Exception as e:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=500, content={"error": True, "message": str(e), "code": "SUMMARY_ERROR"})

@app.get("/api/settlements")
def get_settlements(status: str = None):
    try:
        matched = pd.read_csv("output/settlement_bank_matched.csv") if os.path.exists("output/settlement_bank_matched.csv") else pd.DataFrame()
        review = pd.read_csv("output/settlement_bank_review.csv") if os.path.exists("output/settlement_bank_review.csv") else pd.DataFrame()
        unmatched = pd.read_csv("output/settlement_bank_unmatched.csv") if os.path.exists("output/settlement_bank_unmatched.csv") else pd.DataFrame()
        
        all_data = pd.concat([matched, review, unmatched], ignore_index=True).fillna("")
        if status:
            all_data = all_data[all_data['status'] == status.upper()]
            
        return all_data.to_dict(orient="records")
    except Exception as e:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=500, content={"error": True, "message": str(e), "code": "SETTLEMENTS_ERROR"})

@app.get("/api/ledger")
def get_ledger(status: str = None):
    try:
        all_data = pd.read_csv("output/ledger_bank_all.csv") if os.path.exists("output/ledger_bank_all.csv") else pd.DataFrame()
        all_data = all_data.fillna("")
        if status:
            all_data = all_data[all_data['status'] == status.upper()]
        return all_data.to_dict(orient="records")
    except Exception as e:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=500, content={"error": True, "message": str(e), "code": "LEDGER_ERROR"})

@app.get("/api/unknown_bank")
def get_unknown_bank():
    try:
        if os.path.exists("output/bank_source_review.csv"):
            df = pd.read_csv("output/bank_source_review.csv").fillna("")
            return df.to_dict(orient="records")
        return []
    except Exception as e:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=500, content={"error": True, "message": str(e), "code": "UNKNOWN_BANK_ERROR"})

@app.post("/api/settlements/{settlement_id}/override")
def override_match(settlement_id: str, request: OverrideRequest):
    os.makedirs("data", exist_ok=True)
    override_file = "data/human_overrides.csv"
    new_override = pd.DataFrame([{
        "settlement_id": settlement_id,
        "bank_reference": request.bank_reference,
        "reason": request.reason,
        "user": request.user,
        "timestamp": datetime.now().isoformat()
    }])
    if os.path.exists(override_file):
        existing = pd.read_csv(override_file)
        new_override = pd.concat([existing, new_override], ignore_index=True)
    new_override.to_csv(override_file, index=False)
    
    # Re-run reconciliation agent
    try:
        subprocess.run(["python3", "src/agent.py"], check=True)
    except Exception as e:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=500, content={"error": True, "message": f"Override saved but failed to restart agent: {str(e)}", "code": "RESTART_FAILED"})
        
    return {"message": "Override saved and reconciliation re-run successfully."}

# Mount static UI
app.mount("/", StaticFiles(directory="ui", html=True), name="ui")
