import pandas as pd
from config import RAZORPAY_KEYWORDS

def classify_bank_transaction(bank_row, known_customers=None, known_invoices=None):
    if known_customers is None:
        known_customers = set()
    if known_invoices is None:
        known_invoices = set()
        
    narration = str(bank_row.get("narration", "")).upper()
    bank_ref = str(bank_row.get("bank_reference", "")).upper()
    is_credit = bank_row.get("is_credit", False)
    
    # We only classify credit transactions for now.
    if not is_credit:
        return {
            "source": "UNKNOWN",
            "confidence": 100.0,
            "reason": "Debit transactions are not classified for incoming reconciliation."
        }
        
    combined_text = f"{narration} {bank_ref}"
    
    # 1. Check for Razorpay
    is_rzp = any(kw in combined_text for kw in RAZORPAY_KEYWORDS)
    if is_rzp:
        return {
            "source": "RAZORPAY",
            "confidence": 100.0,
            "reason": "Razorpay identifier found in bank reference or narration."
        }
        
    # 2. Check for Direct Ledger
    # If it contains a known customer name or invoice id
    evidence = []
    
    # Check known invoices
    for inv in known_invoices:
        if len(inv) > 3 and inv in combined_text:
            evidence.append(f"Invoice fragment '{inv}' found.")
            
    # Check known customers
    for cust in known_customers:
        if len(cust) > 3 and cust in combined_text:
            evidence.append(f"Customer name '{cust}' found.")
            
    if evidence:
        return {
            "source": "DIRECT_LEDGER",
            "confidence": 85.0,
            "reason": f"No Razorpay identifier; {'; '.join(evidence)} points toward direct payment."
        }
        
    # 3. Unknown
    return {
        "source": "UNKNOWN",
        "confidence": 30.0,
        "reason": "Generic payment narration with insufficient source evidence."
    }

def classify_bank_transactions(bank_df, ledger_df=None):
    known_customers = set()
    known_invoices = set()
    
    if ledger_df is not None:
        # Extract meaningful fragments
        for _, row in ledger_df.iterrows():
            cust = str(row.get("customer_name", "")).upper()
            if cust:
                # Use largest word as keyword
                words = sorted(cust.split(), key=len, reverse=True)
                if words and len(words[0]) > 3:
                    known_customers.add(words[0])
            
            inv = str(row.get("invoice_id", "")).upper()
            if inv:
                # Extract numeric part
                nums = ''.join(c for c in inv if c.isdigit())
                if len(nums) > 3:
                    known_invoices.add(nums)
                if len(inv) > 3:
                    known_invoices.add(inv)
                    
    results = []
    for i, row in bank_df.iterrows():
        classification = classify_bank_transaction(row, known_customers, known_invoices)
        results.append(classification)
        
    # Append to dataframe
    bank_df["source"] = [r["source"] for r in results]
    bank_df["source_confidence"] = [r["confidence"] for r in results]
    bank_df["source_reason"] = [r["reason"] for r in results]
    
    return bank_df
