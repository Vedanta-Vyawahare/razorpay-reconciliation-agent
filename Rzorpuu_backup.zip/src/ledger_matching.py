"""
Purpose
-------
Ledger → Bank matching engine.

Architecture:
    1. Candidate Discovery  — broad, date-windowed
    2. Evidence Scoring     — via ledger_evidence.py (ledger-specific weights)
    3. Decision Engine      — threshold-based with ambiguity detection

Confidence is a continuous evidence metric (0-100).
Status is a separate decision (MATCHED / REVIEW / UNMATCHED).
"""

import pandas as pd
from ledger_evidence import calculate_ledger_evidence
from services.date_reasoning import business_day_difference

# ============================================================
# LEDGER MATCHING THRESHOLDS
# ============================================================

# Score at or above which a sole candidate is auto-matched
LEDGER_CLAIM_THRESHOLD = 80.0

# Minimum margin between top-2 candidates to claim a match
LEDGER_MARGIN_REQUIRED = 8.0

# Minimum base_score to be considered a viable candidate
LEDGER_MIN_CANDIDATE_SCORE = 15.0

# Score below which the best candidate is considered too weak
LEDGER_REJECT_THRESHOLD = 25.0

# Ambiguity margin: if top two are within this range, force REVIEW
LEDGER_AMBIGUITY_MARGIN = 5.0


# ============================================================
# CANDIDATE DISCOVERY
# ============================================================

def generate_ledger_candidates(ledger_row, bank_df, claimed_bank_indices):
    """
    Broad candidate discovery.
    Only filters on: is_credit and a loose date window (30 days).
    Does NOT filter on amount — the scoring engine handles that.
    """
    candidates = []
    ledger_date = ledger_row.get("ledger_date")

    for i, bank_row in bank_df.iterrows():
        # Skip already-claimed bank rows
        if i in claimed_bank_indices:
            continue

        # Only consider credit transactions
        if not bank_row.get("is_credit", False):
            continue

        # Loose date window (30 business days)
        bank_date = bank_row.get("bank_date")
        if ledger_date is not None and bank_date is not None:
            try:
                if not pd.isna(ledger_date) and not pd.isna(bank_date):
                    diff = abs(business_day_difference(ledger_date, bank_date))
                    if diff > 30:
                        continue
            except Exception:
                pass

        # Score the candidate
        evidence = calculate_ledger_evidence(ledger_row, bank_row)
        score = evidence["base_score"]

        # Keep candidates above minimum viability threshold
        if score >= LEDGER_MIN_CANDIDATE_SCORE:
            candidates.append({
                "bank_index": i,
                "bank_reference": bank_row.get("bank_reference"),
                "bank_date": bank_row.get("bank_date"),
                "bank_amount": bank_row.get("bank_amount"),
                "score": score,
                "evidence": evidence,
            })

    # Sort descending by score
    candidates.sort(key=lambda x: x["score"], reverse=True)
    return candidates


# ============================================================
# DECISION ENGINE
# ============================================================

def match_ledger(ledger_row, bank_df, claimed_bank_indices):
    """
    Match a single ledger row against the bank statement.

    Returns a result dict with:
        - status: MATCHED / REVIEW / UNMATCHED
        - confidence: continuous float (0-100)
        - evidence: detailed evidence breakdown
        - score_explanation: human-readable list of reasons
        - candidate_rankings: all viable candidates
    """

    # 1. Generate Candidates (excluding already-claimed)
    candidates = generate_ledger_candidates(
        ledger_row, bank_df, claimed_bank_indices
    )

    # Base result for no-candidate case
    result = {
        "status": "UNMATCHED",
        "bank_index": None,
        "confidence": 0.0,
        "evidence": None,
        "ambiguity_penalty": 0.0,
        "ambiguity_type": "none",
        "candidate_count": 0,
        "candidate_rankings": candidates,
        "score_explanation": [],
    }

    if not candidates:
        result["score_explanation"].append(
            "No viable candidates found within the date window and scoring threshold."
        )
        return result

    top = candidates[0]
    second = candidates[1] if len(candidates) > 1 else None
    top_score = top["score"]
    second_score = second["score"] if second else 0.0

    result["evidence"] = top["evidence"]
    result["candidate_count"] = len(candidates)

    # --------------------------------------------------------
    # Build explanation
    # --------------------------------------------------------
    explanation = _build_ledger_explanation(ledger_row, top)

    # --------------------------------------------------------
    # CASE 1: Score too low to consider
    # --------------------------------------------------------
    if top_score < LEDGER_REJECT_THRESHOLD:
        result["status"] = "UNMATCHED"
        result["confidence"] = round(top_score, 2)
        result["score_explanation"] = explanation + [
            f"Top candidate score is {top_score:.2f}%, below the "
            f"{LEDGER_REJECT_THRESHOLD:.0f}% rejection threshold."
        ]
        return result

    # --------------------------------------------------------
    # CASE 2: Only one candidate
    # --------------------------------------------------------
    if second is None:
        if top_score >= LEDGER_CLAIM_THRESHOLD:
            result["status"] = "MATCHED"
            result["bank_index"] = top["bank_index"]
            result["confidence"] = round(top_score, 2)
            result["score_explanation"] = explanation + [
                f"Strong isolated candidate with score {top_score:.2f}%."
            ]
        else:
            result["status"] = "REVIEW"
            result["confidence"] = round(top_score, 2)
            result["score_explanation"] = explanation + [
                f"Single candidate with score {top_score:.2f}%, below the "
                f"{LEDGER_CLAIM_THRESHOLD:.0f}% auto-match threshold."
            ]
        return result

    # --------------------------------------------------------
    # CASE 3: Multiple candidates — check ambiguity
    # --------------------------------------------------------
    margin = top_score - second_score

    if top_score >= LEDGER_CLAIM_THRESHOLD and margin >= LEDGER_MARGIN_REQUIRED:
        # Clear winner
        result["status"] = "MATCHED"
        result["bank_index"] = top["bank_index"]
        result["confidence"] = round(top_score, 2)
        result["ambiguity_type"] = "none"
        result["score_explanation"] = explanation + [
            f"Clear winner: {top_score:.2f}% vs second candidate {second_score:.2f}% "
            f"(margin: {margin:.2f}%)."
        ]

    elif margin < LEDGER_AMBIGUITY_MARGIN:
        # Competing candidates — too close to call
        penalty = min(10.0, (LEDGER_AMBIGUITY_MARGIN - margin) * 2.0)
        result["status"] = "REVIEW"
        result["ambiguity_penalty"] = round(penalty, 2)
        result["ambiguity_type"] = "multiple_strong_candidates"
        result["confidence"] = round(max(0.0, top_score - penalty), 2)
        result["score_explanation"] = explanation + [
            f"Multiple competing candidates. Top: {top_score:.2f}%, "
            f"Second: {second_score:.2f}% (margin: {margin:.2f}% < "
            f"{LEDGER_AMBIGUITY_MARGIN:.0f}% threshold).",
            "Human review required to resolve ambiguity."
        ]

    elif top_score < LEDGER_CLAIM_THRESHOLD:
        # Below threshold with competition
        result["status"] = "REVIEW"
        result["confidence"] = round(top_score, 2)
        result["ambiguity_type"] = "multiple_weak_candidates"
        result["score_explanation"] = explanation + [
            f"Best candidate scored {top_score:.2f}%, below the "
            f"{LEDGER_CLAIM_THRESHOLD:.0f}% auto-match threshold."
        ]

    else:
        # Strong enough with sufficient margin
        result["status"] = "MATCHED"
        result["bank_index"] = top["bank_index"]
        result["confidence"] = round(top_score, 2)
        result["ambiguity_type"] = "none"
        result["score_explanation"] = explanation + [
            f"Top candidate scored {top_score:.2f}% with margin "
            f"{margin:.2f}% over second candidate ({second_score:.2f}%)."
        ]

    return result


def _build_ledger_explanation(ledger_row, top_candidate):
    """Build human-readable evidence explanation."""
    ev = top_candidate["evidence"]
    explanation = []

    # Amount
    if ev["amount_score"] >= 45.0:
        explanation.append("Exact amount match.")
    elif ev["amount_score"] >= 30.0:
        explanation.append(f"Amount is close (score: {ev['amount_score']}/45).")
    elif ev["amount_score"] > 0:
        explanation.append(f"Partial amount match (score: {ev['amount_score']}/45).")
    else:
        explanation.append("Amount mismatch.")

    # Date
    if ev["date_score"] >= 25.0:
        explanation.append("Exact date match.")
    elif ev["date_score"] >= 15.0:
        explanation.append(f"Date is close (score: {ev['date_score']}/25).")
    elif ev["date_score"] > 0:
        explanation.append(f"Date within tolerance (score: {ev['date_score']}/25).")
    else:
        explanation.append("Date mismatch or out of range.")

    # Party
    if ev["party_score"] >= 15.0:
        explanation.append("Customer name found in narration.")
    elif ev["party_score"] > 0:
        explanation.append(f"Partial customer name match (score: {ev['party_score']}/15).")
    else:
        explanation.append("Customer name not found in bank narration.")

    # Type
    if ev["transaction_type_score"] >= 10.0:
        explanation.append("Transaction type matches.")
    elif ev["transaction_type_score"] > 0:
        explanation.append(f"Transaction type partially compatible (score: {ev['transaction_type_score']}/10).")
    else:
        explanation.append("Transaction type mismatch.")

    # Reference — NOT APPLICABLE
    explanation.append("Reference/UTR: Not applicable for ledger reconciliation.")

    return explanation
