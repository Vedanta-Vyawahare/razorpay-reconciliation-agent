import pandas as pd
from utils.money import parse_amount
from utils.normalization import normalize_columns

def prepare_ledger(ledger_df):
    """
    Normalize ledger columns and parse dates/amounts.
    """
    df = normalize_columns(ledger_df)
    
    # Ledger Date
    if "invoice_date" in df.columns:
        df["ledger_date"] = pd.to_datetime(df["invoice_date"], format="%Y-%m-%d", errors="coerce")
    else:
        df["ledger_date"] = pd.NaT

    # Ledger Amount
    if "invoice_amount" in df.columns:
        df["ledger_amount"] = df["invoice_amount"].apply(parse_amount)
    else:
        df["ledger_amount"] = None

    # Customer Name
    if "customer_name" not in df.columns:
        df["customer_name"] = ""
        
    # Invoice ID / Ref
    if "invoice_id" not in df.columns:
        df["invoice_id"] = ""

    # Payment Mode
    if "payment_method" in df.columns:
        df["payment_method"] = df["payment_method"].fillna("").astype(str).str.lower().str.strip()
    else:
        df["payment_method"] = ""

    return df
