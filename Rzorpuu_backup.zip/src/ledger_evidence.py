"""
Purpose
-------
Calculates deterministic evidence strength for:

    Internal Ledger → Bank Statement

Ledger Scoring Profile
----------------------
Amount          : 45 points
Date            : 25 points
Party/Customer  : 15 points
Type            : 10 points
Narration       : 5 points
                  ----
                  100 points

Reference / UTR is NOT part of the ledger scoring profile.
Ledger entries do not carry reliable UTR references, so this
evidence dimension is marked NOT_APPLICABLE rather than scored
as 0 (which would be a false negative penalty).

This file does NOT decide which candidate wins.
It only calculates how much evidence each candidate provides.
"""

import pandas as pd
from utils.money import safe_float
from services.date_reasoning import business_day_difference

# ============================================================
# LEDGER-SPECIFIC WEIGHTS
# Reference has ZERO weight — it is not applicable.
# ============================================================
LEDGER_WEIGHTS = {
    "amount": 45.0,
    "date": 25.0,
    "party": 15.0,
    "type": 10.0,
    "narration": 5.0,
}

# ============================================================
# EVIDENCE FUNCTIONS
# ============================================================

def calculate_ledger_evidence(ledger_row, bank_row):
    """
    Returns a dictionary of evidence scores for matching a single
    ledger row against a single bank row.
    """
    ledger_amount = safe_float(ledger_row.get("ledger_amount"))
    bank_amount = safe_float(bank_row.get("bank_amount"))

    amt_score = amount_score(ledger_amount, bank_amount)
    dt_score = date_score(ledger_row.get("ledger_date"), bank_row.get("bank_date"))
    pty_score = party_name_score(ledger_row.get("customer_name"), bank_row.get("narration"))
    typ_score = payment_type_score(ledger_row.get("payment_method"), bank_row.get("transaction_type"))
    narr_score = narration_score(
        ledger_row.get("customer_name"),
        bank_row.get("narration")
    )

    total = amt_score + dt_score + pty_score + typ_score + narr_score

    return {
        "amount_score": round(amt_score, 2),
        "date_score": round(dt_score, 2),
        "party_score": round(pty_score, 2),
        "transaction_type_score": round(typ_score, 2),
        "narration_score": round(narr_score, 2),
        # Reference is NOT APPLICABLE for ledger reconciliation
        "reference_score": None,
        "reference_applicable": False,
        "base_score": round(total, 2),
    }


# ============================================================
# AMOUNT EVIDENCE (45 points max)
# ============================================================

def amount_score(ledger_amt, bank_amt):
    if ledger_amt is None or bank_amt is None:
        return 0.0
    if ledger_amt <= 0 or bank_amt <= 0:
        return 0.0

    max_pts = LEDGER_WEIGHTS["amount"]

    diff = abs(ledger_amt - bank_amt)

    if diff < 0.01:
        return max_pts

    diff_pct = (diff / ledger_amt) * 100

    if diff <= 5.00:
        return round(max_pts * 0.92, 2)
    if diff_pct <= 1.0:
        return round(max_pts * 0.85, 2)
    if diff_pct <= 2.0:
        return round(max_pts * 0.70, 2)
    if diff_pct <= 5.0:
        return round(max_pts * 0.45, 2)
    if diff_pct <= 10.0:
        return round(max_pts * 0.20, 2)

    return 0.0


# ============================================================
# DATE EVIDENCE (25 points max)
# ============================================================

def date_score(ledger_date, bank_date):
    if ledger_date is None or bank_date is None:
        return 0.0
    if pd.isna(ledger_date) or pd.isna(bank_date):
        return 0.0

    max_pts = LEDGER_WEIGHTS["date"]

    try:
        diff = abs(business_day_difference(ledger_date, bank_date))
    except Exception:
        return 0.0

    if diff == 0:
        return max_pts
    if diff <= 1:
        return round(max_pts * 0.90, 2)
    if diff <= 2:
        return round(max_pts * 0.75, 2)
    if diff <= 3:
        return round(max_pts * 0.55, 2)
    if diff <= 5:
        return round(max_pts * 0.35, 2)
    if diff <= 7:
        return round(max_pts * 0.15, 2)
    if diff <= 10:
        return round(max_pts * 0.05, 2)

    return 0.0


# ============================================================
# PARTY / CUSTOMER NAME EVIDENCE (15 points max)
# ============================================================

def normalize_text(text):
    if not isinstance(text, str):
        return ""
    return ''.join(c.lower() for c in str(text) if c.isalnum())


def party_name_score(customer_name, narration):
    if not customer_name:
        return 0.0

    max_pts = LEDGER_WEIGHTS["party"]
    cust_norm = normalize_text(customer_name)
    narr_norm = normalize_text(narration)

    if not cust_norm or not narr_norm:
        return 0.0

    # Full name match
    if cust_norm in narr_norm:
        return max_pts

    # Check individual significant words
    words = str(customer_name).lower().split()
    matched_words = 0
    significant_words = [w for w in words if len(w) > 3]

    if not significant_words:
        return 0.0

    for word in significant_words:
        if normalize_text(word) in narr_norm:
            matched_words += 1

    if matched_words == 0:
        return 0.0

    ratio = matched_words / len(significant_words)

    if ratio >= 0.75:
        return round(max_pts * 0.8, 2)
    if ratio >= 0.5:
        return round(max_pts * 0.5, 2)

    # At least one significant word matched
    return round(max_pts * 0.3, 2)


# ============================================================
# PAYMENT TYPE EVIDENCE (10 points max)
# ============================================================

def payment_type_score(payment_method, transaction_type):
    if not payment_method or not transaction_type:
        return 0.0

    max_pts = LEDGER_WEIGHTS["type"]
    pm = str(payment_method).lower().strip()
    tt = str(transaction_type).upper().strip()

    # Direct type match
    if pm in tt.lower() or tt.lower() in pm:
        return max_pts

    # Netbanking usually arrives as NEFT/RTGS/IMPS
    if pm == "netbanking" and tt in ("NEFT", "RTGS", "IMPS"):
        return max_pts

    # UPI direct match
    if pm == "upi" and tt == "UPI":
        return max_pts

    # Card payments can arrive as NEFT/IMPS (settlement)
    if pm == "card" and tt in ("NEFT", "IMPS", "RTGS"):
        return round(max_pts * 0.6, 2)

    # Wallet payments also settle via NEFT
    if pm in ("wallet", "emi") and tt in ("NEFT", "IMPS", "RTGS"):
        return round(max_pts * 0.5, 2)

    # Generic credit
    if tt in ("TRANSFER", "CREDIT", "UNKNOWN"):
        return round(max_pts * 0.3, 2)

    return 0.0


# ============================================================
# NARRATION EVIDENCE (5 points max)
# ============================================================

def narration_score(customer_name, narration):
    """
    Narration scoring for ledger: checks if the bank narration
    contains meaningful content that correlates with the ledger
    entry. This is a supporting signal, not primary evidence.
    """
    if not narration or pd.isna(narration):
        return 0.0

    max_pts = LEDGER_WEIGHTS["narration"]
    narr = str(narration).lower()

    # Ignore effectively empty narrations
    if len(narr) <= 3 or narr in ("unknown", "none", "na", "nan"):
        return 0.0

    # If customer name appears in narration, that's corroboration
    if customer_name and normalize_text(customer_name) in normalize_text(narration):
        return max_pts

    # Generic non-empty narration has some supporting value
    return round(max_pts * 0.4, 2)
