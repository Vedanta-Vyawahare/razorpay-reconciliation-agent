import pandas as pd

def safe_float(value):
    """
    Safely convert a value to float.
    """
    try:
        if value is None:
            return None
        if pd.isna(value):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None

def get_settlement_amount(settlement):
    """
    Retrieve Razorpay net settlement amount.
    Supports net_settlement and net_amount.
    """
    value = settlement.get(
        "net_settlement",
        settlement.get("net_amount")
    )
    return safe_float(value)

def get_bank_amount(bank_row):
    """
    Retrieve normalized bank credit amount.
    """
    value = bank_row.get("bank_amount")
    return safe_float(value)

def parse_amount(value):
    if pd.isna(value):
        return None
    value = (
        str(value)
        .replace("₹", "")
        .replace(",", "")
        .strip()
    )
    try:
        return round(float(value), 2)
    except ValueError:
        return None
