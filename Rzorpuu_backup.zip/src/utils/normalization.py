import pandas as pd
import re

def normalize_columns(df):
    df = df.copy()
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
    )
    return df

def normalize_identifier(text):
    """
    Normalize reference/UTR by removing spaces and punctuation to allow robust comparison.
    """
    if pd.isna(text) or text is None:
        return ""
    return re.sub(r'[\W_]+', '', str(text)).upper()
