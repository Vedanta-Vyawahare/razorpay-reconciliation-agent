import pandas as pd
from datetime import timedelta

# Default window used if cycle is unknown
DATE_WINDOW_BUSINESS_DAYS = 3

def pd_is_missing(value):
    if value is None:
        return True
    try:
        return pd.isna(value)
    except Exception:
        return False

def safe_date(value):
    if value is None or pd_is_missing(value):
        return None
    try:
        return pd.to_datetime(value)
    except Exception:
        return None

def business_day_difference(date1, date2):
    """
    Calculate the signed number of business days between two dates.
    Positive: date2 occurs after date1.
    Negative: date2 occurs before date1.
    """
    if pd_is_missing(date1) or pd_is_missing(date2):
        return None

    date1 = pd.Timestamp(date1).normalize()
    date2 = pd.Timestamp(date2).normalize()

    if date1 == date2:
        return 0

    direction = 1 if date2 > date1 else -1

    start = min(date1, date2)
    end = max(date1, date2)

    current = start
    business_days = 0

    while current < end:
        current += timedelta(days=1)
        if current.weekday() < 5:
            business_days += 1

    return business_days * direction

def business_day_distance(date1, date2):
    diff = business_day_difference(date1, date2)
    return abs(diff) if diff is not None else None

def signed_business_day_difference(date1, date2):
    return business_day_difference(date1, date2)

def get_cycle_type(settlement):
    cycle = str(settlement.get("settlement_cycle", "")).strip().lower()
    return cycle

def cycle_expected_window(settlement):
    cycle = get_cycle_type(settlement)
    if "t+0" in cycle:
        return 0
    if "t+1" in cycle:
        return 1
    if "t+2" in cycle:
        return 2
    if "t+3" in cycle:
        return 3
    return DATE_WINDOW_BUSINESS_DAYS

def expected_cycle(settlement):
    return cycle_expected_window(settlement)

def get_settlement_date(settlement):
    return safe_date(settlement.get("settlement_date"))

def get_bank_date(bank_row):
    return safe_date(bank_row.get("bank_date"))
