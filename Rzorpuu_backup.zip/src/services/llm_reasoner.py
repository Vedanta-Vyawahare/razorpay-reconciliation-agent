"""
LLM Reasoning Layer for Reconciliation Engine.

Architecture:
    - OPTIONAL enhancement, not a critical dependency
    - Receives structured evidence, NOT raw application state
    - Cannot override failed-settlement or strong deterministic matches
    - Gracefully handles 429 / quota exhaustion
    - Falls back to deterministic text when LLM is unavailable

Gemini 3.6 Flash integration with bounded retry and circuit breaker.
"""

import os
import json
import time
from dotenv import load_dotenv

load_dotenv()


class ReconciliationReasoner:
    """
    LLM abstraction layer for explaining reconciliation decisions.
    
    Uses Google Gemini when available, with:
    - Circuit breaker for 429 quota exhaustion
    - Bounded retry (max 1 retry with backoff)
    - Structured evidence prompts
    - Deterministic fallback for all cases
    """

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.use_llm = bool(self.api_key)
        self.model = None
        self._quota_exhausted = False
        self._call_count = 0
        self._max_calls_per_run = 10  # Budget per reconciliation run

        if self.use_llm:
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel('gemini-1.5-flash')
                self.use_llm = True
            except ImportError:
                print("Warning: google-generativeai package not found. Using deterministic reasoning.")
                self.use_llm = False
            except Exception as e:
                print(f"Warning: Failed to initialize Gemini: {e}")
                self.use_llm = False

    def _can_call_llm(self):
        """Check if LLM calls are allowed (quota + budget)."""
        if not self.use_llm or self.model is None:
            return False
        if self._quota_exhausted:
            return False
        if self._call_count >= self._max_calls_per_run:
            return False
        return True

    def _call_llm(self, prompt, max_tokens=200):
        """
        Call Gemini with circuit breaker and bounded retry.
        Returns None on any failure (caller uses deterministic fallback).
        """
        if not self._can_call_llm():
            return None

        self._call_count += 1

        try:
            response = self.model.generate_content(
                prompt,
                generation_config=dict(
                    temperature=0.2,
                    max_output_tokens=max_tokens,
                )
            )
            return response.text.strip()

        except Exception as e:
            error_str = str(e)

            # Circuit breaker: detect quota exhaustion
            if "429" in error_str or "quota" in error_str.lower() or "rate" in error_str.lower():
                self._quota_exhausted = True
                print("LLM: Gemini quota exhausted. Switching to deterministic reasoning for remaining items.")
                return None

            # Any other error — log briefly and continue
            print(f"LLM: Gemini error (non-fatal): {error_str[:100]}")
            return None

    # ============================================================
    # STRUCTURED EVIDENCE REASONING
    # ============================================================

    def explain_match(self, source_type, evidence, confidence, status, candidate_info=None):
        """
        Generate a human-readable explanation for a reconciliation decision.
        
        Args:
            source_type: "razorpay" or "ledger"
            evidence: dict with individual scores
            confidence: float, overall confidence
            status: "MATCHED", "REVIEW", or "UNMATCHED"
            candidate_info: optional dict with candidate details
        """
        # Build structured evidence payload
        structured = self._build_structured_evidence(
            source_type, evidence, confidence, status, candidate_info
        )

        # For MATCHED with high confidence, deterministic is fine
        if status == "MATCHED" and confidence >= 95.0:
            return self._deterministic_explanation(structured)

        # For UNMATCHED with very low confidence, deterministic is fine
        if status == "UNMATCHED" and confidence < 10.0:
            return self._deterministic_explanation(structured)

        # For borderline / REVIEW cases, try LLM
        llm_response = self._try_llm_explanation(structured)
        if llm_response:
            return f"🤖 {llm_response}"

        # Fallback
        return self._deterministic_explanation(structured)

    def _build_structured_evidence(self, source_type, evidence, confidence, status, candidate_info):
        """Build a structured evidence dict for LLM consumption."""
        if evidence is None:
            evidence = {}

        structured = {
            "source": source_type,
            "confidence": confidence,
            "status": status,
            "evidence": {
                "amount": {
                    "score": evidence.get("amount_score", 0),
                    "max": 40.0 if source_type == "razorpay" else 45.0,
                },
                "date": {
                    "score": evidence.get("date_score", 0),
                    "max": 15.0 if source_type == "razorpay" else 25.0,
                },
            }
        }

        if source_type == "razorpay":
            structured["evidence"]["reference"] = {
                "score": evidence.get("reference_score", 0),
                "max": 35.0,
                "applicable": True,
            }
            structured["evidence"]["type"] = {
                "score": evidence.get("transaction_type_score", 0),
                "max": 5.0,
            }
            structured["evidence"]["narration"] = {
                "score": evidence.get("narration_score", 0),
                "max": 5.0,
            }
        else:
            structured["evidence"]["reference"] = {
                "applicable": False,
                "reason": "UTR/reference is not part of ledger reconciliation.",
            }
            structured["evidence"]["party"] = {
                "score": evidence.get("party_score", 0),
                "max": 15.0,
            }
            structured["evidence"]["type"] = {
                "score": evidence.get("transaction_type_score", 0),
                "max": 10.0,
            }
            structured["evidence"]["narration"] = {
                "score": evidence.get("narration_score", 0),
                "max": 5.0,
            }

        if candidate_info:
            structured["candidate"] = candidate_info

        return structured

    def _try_llm_explanation(self, structured):
        """Attempt to get LLM explanation for borderline cases."""
        evidence_json = json.dumps(structured, indent=2, default=str)

        prompt = f"""You are a financial reconciliation expert. Analyze this evidence and explain the decision in 2-3 concise sentences for an accountant.

Evidence:
{evidence_json}

Rules:
- Do NOT override the deterministic status decision.
- Explain WHY the evidence supports or weakens the match.
- If reference is not applicable, do not penalize for its absence.
- Be specific about which evidence dimensions are strong vs weak.
- Keep it under 50 words."""

        return self._call_llm(prompt, max_tokens=150)

    def _deterministic_explanation(self, structured):
        """Generate a deterministic explanation from structured evidence."""
        source = structured["source"]
        confidence = structured["confidence"]
        status = structured["status"]
        ev = structured["evidence"]

        parts = []

        # Amount assessment
        amt = ev.get("amount", {})
        amt_score = amt.get("score", 0)
        amt_max = amt.get("max", 45)
        if amt_score >= amt_max:
            parts.append("Exact amount match")
        elif amt_score >= amt_max * 0.7:
            parts.append("Amount is close")
        elif amt_score > 0:
            parts.append("Partial amount match")
        else:
            parts.append("Amount mismatch")

        # Date assessment
        dt = ev.get("date", {})
        dt_score = dt.get("score", 0)
        dt_max = dt.get("max", 25)
        if dt_score >= dt_max:
            parts.append("exact date")
        elif dt_score >= dt_max * 0.5:
            parts.append("date within tolerance")
        elif dt_score > 0:
            parts.append("date is distant")
        else:
            parts.append("date mismatch")

        # Reference (only for Razorpay)
        ref = ev.get("reference", {})
        if ref.get("applicable", False):
            ref_score = ref.get("score", 0)
            if ref_score >= 30:
                parts.append("strong reference match")
            elif ref_score > 0:
                parts.append("partial reference match")
            else:
                parts.append("reference mismatch")
        elif source == "ledger":
            parts.append("reference N/A (ledger)")

        result = ". ".join([p.capitalize() for p in parts]) + "."

        if status == "REVIEW":
            result += " Manual review recommended."
        elif status == "MATCHED":
            result += " Automatically matched."

        return result

    # ============================================================
    # LEGACY API (backward compatible)
    # ============================================================

    def explain_ambiguity(self, candidates):
        """Legacy method for backward compatibility with agent.py."""
        if not candidates:
            return "No valid candidates."

        if len(candidates) < 2:
            if candidates:
                return f"Single candidate with score {candidates[0].get('score', 0):.1f}%."
            return "Low confidence match."

        top = candidates[0]
        second = candidates[1]

        # Try LLM for ambiguous cases
        if self._can_call_llm():
            structured = {
                "type": "ambiguity_resolution",
                "candidate_1": {
                    "score": top.get("score"),
                    "amount": top.get("bank_amount"),
                    "date": str(top.get("bank_date")),
                    "reference": top.get("bank_reference"),
                },
                "candidate_2": {
                    "score": second.get("score"),
                    "amount": second.get("bank_amount"),
                    "date": str(second.get("bank_date")),
                    "reference": second.get("bank_reference"),
                },
            }
            prompt = f"""Two bank transactions are competing to match one settlement. Explain why human review is needed in 2 sentences.
Candidate 1: Score {top['score']:.1f}%, Amount {top.get('bank_amount')}, Ref {top.get('bank_reference')}
Candidate 2: Score {second['score']:.1f}%, Amount {second.get('bank_amount')}, Ref {second.get('bank_reference')}"""

            llm_result = self._call_llm(prompt, 100)
            if llm_result:
                return f"🤖 {llm_result}"

        # Deterministic fallback
        return (
            f"Ambiguity: Candidate '{top.get('bank_reference')}' ({top['score']:.1f}%) vs "
            f"'{second.get('bank_reference')}' ({second['score']:.1f}%). "
            "Scores too close — human review required."
        )

    def explain_exception(self, settlement, candidate, evidence):
        """Legacy method."""
        if self._can_call_llm():
            prompt = (
                f"Settlement {settlement.get('settlement_id')} expected ₹{settlement.get('net_amount')} "
                f"on {settlement.get('settlement_date')}. Best candidate scored {evidence.get('base_score', 0)}%. "
                "Explain why this is an exception in 1-2 sentences."
            )
            result = self._call_llm(prompt, 100)
            if result:
                return f"🤖 {result}"

        return "Exception flagged: evidence is insufficient or contradictory. Manual verification required."

    def get_status(self):
        """Return LLM availability status for diagnostics."""
        return {
            "llm_available": self.use_llm and self.model is not None,
            "quota_exhausted": self._quota_exhausted,
            "calls_made": self._call_count,
            "calls_remaining": max(0, self._max_calls_per_run - self._call_count),
        }
