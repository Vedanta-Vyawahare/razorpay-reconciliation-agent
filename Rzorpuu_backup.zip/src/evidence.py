"""
Purpose
-------
Calculates deterministic evidence strength for a possible:

    Razorpay Settlement -> Bank Statement

Confidence model
----------------
Amount relationship       : 75 points
Settlement timing         : 15 points
Transaction type          : 7 points
Narration                 : 3 points
                            ----
                            100 points

Important
---------
These are EVIDENCE POINTS, not statistical probabilities.

Ambiguity is handled separately in matching.py and can apply
a small penalty of 0% to 1%.

This file does NOT decide which candidate wins.
It only calculates how much evidence each candidate provides.
"""

import pandas as pd

from config import WEIGHTS, RAZORPAY_KEYWORDS, EXACT_AMOUNT_TOLERANCE, SMALL_AMOUNT_TOLERANCE

from datetime import timedelta
from services.date_reasoning import safe_date, business_day_difference, expected_cycle, pd_is_missing
from utils.money import get_settlement_amount


# ============================================================
# HELPERS
# ============================================================




# ============================================================
# AMOUNT EVIDENCE
# ============================================================

def amount_score(
    settlement_amount,
    bank_amount
):
    """
    Amount evidence.

    Maximum:
        WEIGHTS["amount"]

    Exact net settlement amount receives full evidence.
    """

    max_score = WEIGHTS["amount"]

    if (
        settlement_amount is None
        or bank_amount is None
    ):
        return 0.0

    try:

        settlement_amount = float(
            settlement_amount
        )

        bank_amount = float(
            bank_amount
        )

    except (
        TypeError,
        ValueError
    ):

        return 0.0

    if settlement_amount <= 0:
        return 0.0

    difference = abs(
        settlement_amount
        - bank_amount
    )

    if difference <= EXACT_AMOUNT_TOLERANCE:
        return max_score

    # Percentage difference relative to settlement amount
    percentage_difference = (
        difference
        / settlement_amount
    ) * 100

    # Small absolute differences (e.g. rounding) should still
    # contribute meaningful evidence. Use configured small
    # tolerance as a guideline.
    try:
        small_abs_threshold = float(SMALL_AMOUNT_TOLERANCE)
    except Exception:
        small_abs_threshold = 1.0

    # Score curve (heuristic): gradually degrade evidence as
    # percentage difference increases.
    if difference <= small_abs_threshold:
        return max_score * 0.9

    if percentage_difference <= 1.0:
        return max_score * 0.8

    if percentage_difference <= 3.0:
        return max_score * 0.5

    if percentage_difference <= 7.0:
        return max_score * 0.25

    return 0.0


def date_score(settlement, bank_date):
    """
    Date evidence.

    Maximum:
        WEIGHTS["date"]

    Compares Razorpay settlement_date with the
    actual bank credit date using business days.
    """

    settlement_date = settlement.get(
        "settlement_date"
    )

    settlement_date = safe_date(
        settlement_date
    )

    bank_date = safe_date(
        bank_date
    )

    if (
        settlement_date is None
        or bank_date is None
    ):
        return 0.0

    difference = abs(
        business_day_difference(
            settlement_date,
            bank_date
        )
    )

    max_score = WEIGHTS["date"]

    if difference == 0:
        return max_score

    if difference == 1:
        return max_score * 0.90

    if difference == 2:
        return max_score * 0.75

    if difference == 3:
        return max_score * 0.55

    if difference == 4:
        return max_score * 0.35

    if difference == 5:
        return max_score * 0.15

    return 0.0


# ============================================================
# REFERENCE EVIDENCE
# ============================================================

def reference_score(settlement_utr, bank_reference, narration):
    max_score = WEIGHTS.get("reference", 35.0)
    
    if pd_is_missing(settlement_utr):
        return 0.0
        
    s_utr = str(settlement_utr).upper().strip()
    b_ref = str(bank_reference).upper().strip() if not pd_is_missing(bank_reference) else ""
    narr = str(narration).upper().strip() if not pd_is_missing(narration) else ""
    
    s_norm = ''.join(c for c in s_utr if c.isalnum())
    b_norm = ''.join(c for c in b_ref if c.isalnum())
    n_norm = ''.join(c for c in narr if c.isalnum())
    
    if s_norm and s_norm == b_norm:
        return max_score
        
    if s_norm and (s_norm in b_norm or s_norm in n_norm):
        return max_score
        
    # Check if the numeric part matches
    s_nums = ''.join(c for c in s_utr if c.isdigit())
    if len(s_nums) >= 6:
        if s_nums in b_ref or s_nums in narr:
            return max_score * 0.8
            
    return 0.0


# ============================================================
# TRANSACTION TYPE EVIDENCE
# ============================================================

def transaction_type_score(bank_row):
    """
    Transaction type evidence.

    Maximum:
        WEIGHTS["transaction_type"]

    Razorpay settlements normally arrive as incoming
    bank credits.

    NEFT / IMPS / RTGS are strong transfer mechanisms.

    Generic incoming transfers provide weaker evidence.
    """

    max_score = WEIGHTS[
        "transaction_type"
    ]

    if not bank_row.get(
        "is_credit",
        False
    ):
        return 0.0

    transaction_type = str(
        bank_row.get(
            "transaction_type",
            "UNKNOWN"
        )
    ).upper()

    if transaction_type in {
        "NEFT",
        "IMPS",
        "RTGS"
    }:
        return max_score

    if transaction_type == "TRANSFER":
        return max_score * 0.70

    if transaction_type in {
        "UPI",
        "CREDIT"
    }:
        return max_score * 0.40

    return max_score * 0.15


# ============================================================
# NARRATION EVIDENCE
# ============================================================

def narration_score(narration):
    """
    Narration evidence.

    Maximum:
        WEIGHTS["narration"]

    This is deliberately a supporting signal.

    We should NOT make narration a primary matching key
    because bank narrations are inconsistent.
    """

    max_score = WEIGHTS[
        "narration"
    ]

    if pd_is_missing(narration):
        return 0.0

    text = str(
        narration
    ).upper()

    # Strong Razorpay identifiers.
    strong_keywords = [
        keyword.upper()
        for keyword in RAZORPAY_KEYWORDS
    ]

    for keyword in strong_keywords:

        if keyword in text:
            return max_score

    # Generic settlement wording is weak evidence.
    weak_terms = [
        "SETTLEMENT",
        "PAYOUT",
        "PAYMENT GATEWAY",
        "PG"
    ]

    for term in weak_terms:

        if term in text:
            return max_score * 0.40

    return 0.0


# ============================================================
# COMPLETE EVIDENCE
# ============================================================

def calculate_evidence(settlement, bank_rows):
    """
    Calculate evidence for a Razorpay settlement -> bank statement match.

    bank_rows may be:
        1. A pandas DataFrame containing multiple bank rows
        2. A pandas Series containing one bank row

    For Razorpay lump-sum settlements, multiple bank credits
    may collectively represent the settlement.
    """

    settlement_amount = get_settlement_amount(
        settlement
    )

    if settlement_amount is None:
        return {
            "amount_score": 0.0,
            "date_score": 0.0,
            "reference_score": 0.0,
            "transaction_type_score": 0.0,
            "narration_score": 0.0,
            "base_score": 0.0,
        }

    # --------------------------------------------------------
    # NORMALIZE INPUT
    # --------------------------------------------------------

    if isinstance(bank_rows, pd.Series):

        bank_rows = bank_rows.to_frame().T

    elif not isinstance(bank_rows, pd.DataFrame):

        return {
            "amount_score": 0.0,
            "date_score": 0.0,
            "reference_score": 0.0,
            "transaction_type_score": 0.0,
            "narration_score": 0.0,
            "base_score": 0.0,
        }

    if bank_rows.empty:

        return {
            "amount_score": 0.0,
            "date_score": 0.0,
            "reference_score": 0.0,
            "transaction_type_score": 0.0,
            "narration_score": 0.0,
            "base_score": 0.0,
        }

    # --------------------------------------------------------
    # AMOUNT
    # --------------------------------------------------------

    bank_amounts = pd.to_numeric(
        bank_rows["bank_amount"],
        errors="coerce"
    ).fillna(0.0)

    total_bank_amount = round(
        bank_amounts.sum(),
        2
    )

    amount = amount_score(
        settlement_amount,
        total_bank_amount
    )

    # --------------------------------------------------------
    # DATE
    # --------------------------------------------------------

    bank_dates = bank_rows[
        "bank_date"
    ].dropna()

    if len(bank_dates) > 0:

        # For a grouped settlement, use the latest
        # credit date as the settlement arrival date.
        bank_date = bank_dates.max()

    else:

        bank_date = None

    date = date_score(
        settlement,
        bank_date
    )

    # --------------------------------------------------------
    # TRANSACTION TYPE
    # --------------------------------------------------------

    transaction_type = group_transaction_type_score(
        bank_rows
    )

    # --------------------------------------------------------
    # NARRATION
    # --------------------------------------------------------

    narrations = bank_rows[
        "narration"
    ].dropna().astype(str)

    narration = group_narration_score(
        bank_rows
    )

    # --------------------------------------------------------
    # REFERENCE
    # --------------------------------------------------------
    
    bank_ref = bank_rows["bank_reference"].iloc[0] if "bank_reference" in bank_rows and not bank_rows["bank_reference"].empty else ""
    narr_val = bank_rows["narration"].iloc[0] if "narration" in bank_rows and not bank_rows["narration"].empty else ""
    reference = reference_score(
        settlement.get("settlement_utr"),
        bank_ref,
        narr_val
    )

    # --------------------------------------------------------
    # TOTAL EVIDENCE
    # --------------------------------------------------------

    base_score = (
        amount
        + date
        + reference
        + transaction_type
        + narration
    )

    return {

        "amount_score":
            round(amount, 2),

        "date_score":
            round(date, 2),

        "reference_score":
            round(reference, 2),

        "transaction_type_score":
            round(transaction_type, 2),

        "narration_score":
            round(narration, 2),

        "base_score":
            round(base_score, 2),

        # Useful for debugging/output
        "bank_total":
            total_bank_amount,

        "bank_row_count":
            len(bank_rows),
    }

def group_transaction_type_score(bank_rows):

    if len(bank_rows) == 0:
        return 0.0

    if not bank_rows["is_credit"].all():
        return 0.0

    types = set(
        bank_rows["transaction_type"]
        .astype(str)
        .str.upper()
    )

    if types & {"NEFT", "IMPS", "RTGS"}:
        return WEIGHTS.get("transaction_type", 7.0)

    if "TRANSFER" in types:
        return 5.0

    return 2.0

def group_narration_score(bank_rows):

    text = " ".join(
        bank_rows["narration"]
        .fillna("")
        .astype(str)
        .str.upper()
    )

    for keyword in RAZORPAY_KEYWORDS:
        if keyword in text:
            return WEIGHTS.get("narration", 3.0)

    # Small supporting score when any narration text exists.
    return max(0.0, WEIGHTS.get("narration", 3.0) * 0.15)

